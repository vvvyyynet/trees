const n=`#formal
#2

# Reduction of complexity through visual categorisation

## Description

By reducing complexity through the use of distinctive visual categories, maps tend to limit the promotion of diversity and plural perspectives.

## Application

## References

Presner et al., 2014
Costanza-Chock, 2018
`;export{n as default};
