import{e}from"./runtime.DiIO-n5k.js";e();
