import{o as a}from"./runtime.Dd0jTHCb.js";a();
