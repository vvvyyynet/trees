const e=`#formal #usability
#1

# Lack of vocabulary for biodiversity issues

## Description

Grenzen von Schutzbemühungen oder -gebieten sind oft übereinstimmend mit den kartierten, ­rechtlichen Grenzen (z. B. Landesgrenzen). Natürliche Ökosysteme oder klimatische Einflüsse (globale Erwärmung, Extremwetterereignisse) etc. kennen jedoch keine Grenzen.

## Application

Ökosystemleistungen von Bäumen > es fehlt an konsistenten Methoden für die Erfassung und Visualisierung von solchen Daten

## References

- Aït-Touati et al. 2022
- Kennedy et al. 2016
`;export{e as default};
