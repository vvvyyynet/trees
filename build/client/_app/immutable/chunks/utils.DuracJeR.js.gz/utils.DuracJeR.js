import{n as e,e as b}from"./runtime.Dd0jTHCb.js";function o(n,u,r){if(n==null)return u(void 0),e;const s=b(()=>n.subscribe(u,r));return s.unsubscribe?()=>s.unsubscribe():s}export{o as s};
