import{a as t}from"../chunks/entry.DeStPbd-.js";export{t as start};
