import{a as t}from"../chunks/entry.C3vVJj8r.js";export{t as start};
