import{a as t}from"../chunks/entry.5FZYlQ7u.js";export{t as start};
