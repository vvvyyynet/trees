import{a as t}from"../chunks/entry.Dx4mm2hv.js";export{t as start};
