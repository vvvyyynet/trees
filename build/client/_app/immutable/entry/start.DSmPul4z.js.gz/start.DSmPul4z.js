import{a as t}from"../chunks/entry.C7MbjuMe.js";export{t as start};
