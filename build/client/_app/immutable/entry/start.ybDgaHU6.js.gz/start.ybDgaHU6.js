import{a as t}from"../chunks/entry.BFqWn5bO.js";export{t as start};
