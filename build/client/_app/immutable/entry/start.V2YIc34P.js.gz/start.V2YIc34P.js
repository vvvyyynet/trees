import{a as t}from"../chunks/entry.MaRXoTCJ.js";export{t as start};
