import{a as t}from"../chunks/entry.CT6HkUhM.js";export{t as start};
