import{a as i,t as a}from"../chunks/disclose-version.M3PKwsxC.js";import"../chunks/legacy.BehYRBVN.js";var o=a(`<div class="mt-5 w-full px-4 md:mt-10 md:max-w-[1200px] md:px-20"><p>Trees are of central importance to urban life, providing vital services for the urban climate,
		human health, and biodiversity. In light of the climate crisis, urban planning needs to take
		greater account of their ecological functions as well as protect them from harmful effects.
		However, there is a lack of cartographic tools to comprehensively represent and communicate
		relevant information.</p> <p>The PhD project aims to develop cartographic visualisations that help to communicate the complex
		ecological functions of trees and thereby improve knowledge transfer in urban planning. The
		project will investigate the production processes of ecological maps as well as their reception
		and use in the field. Based on this, new forms of map visualisation will be explored and
		evaluated. The goal is to provide a research-based basis for the discussion of ecologically
		sustainable urban planning.</p> <p>This project contributes to the need for new planning principles to integrate trees into
		sustainable urban development. By providing evidence-based insights for improved information
		transfer, it will contribute to the promotion of urban climate, quality of life and
		biodiversity. Given the widespread use of maps to visualise the state of biodiversity, their
		impact needs to be considered holistically. As critical map and data studies have shown,
		cartographic design influences not only the perception of the natural environment but also the
		resulting conservation concepts.</p> <img class="mx-auto mt-24" src="/images/Visualisierung_Baumoekosysteme.png" alt="Visualisierung Baumökosysteme"></div>`);function r(e){var t=o();i(e,t)}export{r as component};
